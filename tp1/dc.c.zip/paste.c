#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>

#include <stdlib.h>

//ssize_t getline(char** buffer, size_t* capacidad, FILE* archivo);

int paste(FILE* arch1, FILE* arch2){	
	char* linea1 = NULL;
	size_t capacidad1 = 0;
	char* linea2 = NULL;
	size_t capacidad2 = 0;
	ssize_t longitud1 = getline(&linea1, &capacidad1, arch1);
	ssize_t longitud2 = getline(&linea2, &capacidad2, arch2);
	if (longitud1 == -1 || longitud2 == -1){
			fprintf(stderr, "Error");		
			return -1;
			}
	while (longitud1 != -1 && longitud2 != -1){
		linea1[longitud1-1] = '\0';
		fprintf(stdout, "%s  \t %s", linea1, linea2);	
		longitud1 = getline(&linea1, &capacidad1, arch1);
		longitud2 = getline(&linea2, &capacidad2, arch2);		
		if (longitud1 == -1 || longitud2 == -1){
			fprintf(stderr, "Error\n");		
			return -1;
			}		
		}
	free(linea1);
	free(linea2);	
	return 0;
	}


int main(int argc, char *argv[]) {
	if (argc != 3){
		fprintf(stderr, "Error, la cantidad de archivos no es la correcta \n");
		return 1;	
		}		
	FILE* arch1 = fopen(argv[1],"r");
	FILE* arch2 = fopen(argv[2],"r");		
	int c = paste(arch1, arch2);
	fclose(arch1);	
	fclose(arch2);
	return c;				
}


