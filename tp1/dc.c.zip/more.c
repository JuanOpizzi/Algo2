#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>

#include <stdlib.h>

//ssize_t getline(char** buffer, size_t* capacidad, FILE* archivo);

void more(FILE* arch, int N){	
	char* linea = NULL;
	size_t capacidad = 0;
	ssize_t longitud = getline(&linea, &capacidad, arch);
	int i = 1;	
	while (longitud != -1 && i <= N){
			linea[longitud-1] = '\0';
			fprintf(stdout, "%s \n", linea);
			longitud = getline(&linea, &capacidad, arch);
			i++;				
		}
	int A = getchar();
	while (A == '\n' && longitud != -1){
		linea[longitud-1] = '\0';
		fprintf(stdout, "%s ", linea);
		longitud = getline(&linea, &capacidad, arch);
		A = getchar();		
		}
	free(linea);
	return;
	}


int main(int argc, char *argv[]) {
	int n = atoi(argv[2]);	
	if (argc != 3){
		fprintf(stderr, "Error, la cantidad de archivos no es la correcta \n");
		return 1;	
		}		
	else if (n > 0){
		FILE* arch = fopen(argv[1],"r");		
		more(arch, n);
		fclose(arch);
		return 0;
	}		
	return 1;
}




