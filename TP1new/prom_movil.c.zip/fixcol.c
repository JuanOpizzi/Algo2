#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>

#include <stdlib.h>

void fixcol(FILE* arch, int N){
	char* buffer = malloc(N + 1);
	if(!buffer){
		fprintf(stderr, "Error interno al pedir memoria\n");
		return ;
	}
	while (!feof(arch)){
		fread(buffer, 1, N, arch);
		buffer[N] = '\0';
		printf("%s\n", buffer);
    	}
    	free(buffer);
	return ;
}



int main(int argc, char *argv[]) {
	int n = atoi(argv[2]);	
	if (argc != 3){
		fprintf(stderr, "Error, la cantidad de archivos no es la correcta\n");
		return 1;	
	}		
	else if (n > 0){
		FILE* arch = fopen(argv[1],"r");		
		fixcol(arch, n);
		fclose(arch);
		return 0;
	}		
	return 1;
}

