#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
//#include "strutil.c"
#include "pila.h"

//struct pila;  // Definición completa en pila.c.
//typedef struct pila pila_t;


pila_t* pila_crear(void);
void pila_destruir(pila_t *pila);
bool pila_esta_vacia(const pila_t *pila);
bool pila_apilar(pila_t *pila, void* valor);
void* pila_ver_tope(const pila_t *pila);
void* pila_desapilar(pila_t *pila);

char** split(const char* str, char sep);
void free_strv(char *strv[]);
//double strtod(const char *str, char **endptr); 
//void isdigit(int c);
//double atof(const char *str); 

int funcion_auxiliar(char* pos){
	int i = 0;
	size_t largo_pos = strlen(pos);
	if (largo_pos == 1){
		if(isdigit(pos[0]) != 0){		
			return 0;				
			}	
		else if (pos[0] == '+'){
			return 1;
			}
		else if (pos[0] == '-'){ 
			return 2;
			}
		else if (pos[0] == '*'){
			return 3;
			}
		else if (pos[0] == '/'){
			return 4;
			}			
		}
	else if (largo_pos > 1){
		while (i < largo_pos){
			if(isdigit(pos[i]) != 0){				
				i++;
				}
			else{ return -1;}
			}
		return 0;
		}						
	return -1;
}

int dc(){
	printf("por que? ");
	double* aux;
	double*  num1;
	double*  num2;
	double*  num3;
	int i = 0;
	pila_t* pila = pila_crear();
	char* linea = NULL;
	size_t capacidad = 0;
	printf("hola ");
	ssize_t longitud = getline(&linea, &capacidad, stdin);
	printf("bocha pecho frio ");
	while (longitud != -1){	
		linea[longitud-1] = '\0';
		char** arreglo = split(linea, ' '); // aca mas bien
		printf("adios ");
		while (arreglo[i] != NULL){
			printf("jaja ");	
			int A = funcion_auxiliar(arreglo[i]);
			if (A == 0){
				*aux = (atof(arreglo[i]));
				pila_apilar(pila, &aux);
				}
			else if (A!=-1 && A!=0){
				num1 = pila_desapilar(pila);				
				num2 = pila_desapilar(pila);	
				if (A == 1){		
					*num3 = (*num2 + *num1);
					}
				else if (A == 2){		
					*num3 = (*num2 - *num1);
					}
				else if (A == 3){		
					*num3 = (*num2 * *num1);
					}
				else if (A == 4){	
					*num3 = (*num2 / *num1);
					}
				printf("fin \n");
				if(pila_esta_vacia(pila)){
					printf("%0.2f\n", *num3);	
					}
				else if (!pila_esta_vacia(pila)){
					pila_apilar(pila, &num3);
					}				
				printf("llegue aca \n");				
				}			
				//
			else{
				fprintf(stderr, "Error, se ingreso un caracter invalido en la funcion\n");
				return 1;
				}
		i++;			
		}
		free_strv(arreglo);
		longitud = getline(&linea, &capacidad, stdin);
		}
	free(linea);
	pila_destruir(pila);
	return 0;
}


int main(int argc, char *argv[]) {				
	int c = dc();
	return c;				
}

