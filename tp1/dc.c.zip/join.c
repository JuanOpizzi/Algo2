#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* join(char** strv, char sep){
	int tam = 0;
	int z   = 0;
	int i   = 0;
	size_t b= 0;
	while (strv[tam] != NULL){
		b += (strlen(strv[tam])+1);
		tam++;		
		}			
	char * cadena = malloc((b+1) * sizeof(char));
	if (tam == 0){ 
		cadena[0] = '\0';
		return cadena;
		}	
	for (int y=0; y < tam; y++){
		while(strv[y][z] != '\0'){ 
			cadena[i] = strv[y][z];
			i++;
			z++;		
			}
		cadena[i] = sep;
		i++;
		z=0;	
		}	
	cadena[i-1]= '\0';
	return cadena;
}
	
