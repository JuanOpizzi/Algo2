#include "join.h"
#include <stdio.h>
#include <stdlib.h>
int main(){		
	char** hola = malloc(5 * sizeof(char*));
	char* a = "hola";
	char* b = "mundo";
	char* c = "que";
	char* d = "onda";	
	hola[0] = a; 	
	hola[1] = b;
	hola[2] = c;
	hola[3] = d;
	hola[4] = NULL;	
	char* retorno = join(hola, ',');
	printf("%s \n", retorno);
	free(retorno);
	free(hola);
	char** lore = malloc(1 * sizeof(char*));
	lore[0] = NULL;
	char* regreso = join(lore, ',');
	printf("%s \n", regreso);
	free(regreso);
	free(lore);
	return 0;	
}
